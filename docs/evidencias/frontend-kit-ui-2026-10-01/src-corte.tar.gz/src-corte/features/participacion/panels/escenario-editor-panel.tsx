"use client";

import { PanelShell } from "@/core/panels/panel-shell";
import { usePanels } from "@/core/panels/panel-store";
import { SectionLabel } from "@/shared/components/participation-ui";
import { Button } from "@/shared/ui/button";
import { Input } from "@/shared/ui/input";
import { Label } from "@/shared/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/shared/ui/select";

export function EscenarioEditorPanel({ entryKey }: { entryKey: string }) {
  const { closeTop } = usePanels();

  return (
    <PanelShell
      entryKey={entryKey}
      title="Registrar Escenario Especial"
      subtitle="Captura de asistencia para foros, consultas previas y talleres"
      crumbs={[{ label: "Participación" }, { label: "Nuevo Escenario" }]}
      onClose={closeTop}
      onCloseToKey={closeTop}
      footer={
        <div className="flex justify-end gap-2 w-full">
          <Button variant="outline" onClick={closeTop}>Cancelar</Button>
          <Button>Guardar Escenario</Button>
        </div>
      }
    >
      <div className="p-6 space-y-8">
        <section className="space-y-4">
          <SectionLabel>Datos Generales</SectionLabel>
          <div className="space-y-2">
            <Label>Título del Escenario</Label>
            <Input placeholder="Ej. Foro Sectorial de Movilidad Sostenible" />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Tipo de Escenario</Label>
              <Select defaultValue="foro_sectorial">
                <SelectTrigger>
                  <SelectValue placeholder="Selecciona" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="foro_sectorial">Foro Sectorial</SelectItem>
                  <SelectItem value="consulta_previa">Consulta Previa</SelectItem>
                  <SelectItem value="taller_juvenil">Taller Juvenil</SelectItem>
                  <SelectItem value="otro">Otro</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Fecha</Label>
              <Input type="date" />
            </div>
          </div>
          <div className="space-y-2">
            <Label>Entidad Convocante</Label>
            <Input placeholder="Ej. Secretaría de Planeación" />
          </div>
        </section>

        <section className="space-y-4">
          <SectionLabel>Desglose de Asistencia (Estimado / Planillas)</SectionLabel>
          <div className="grid grid-cols-3 gap-4 p-4 rounded-xl border border-[var(--border)] bg-[var(--surface-1)]">
            <div className="space-y-2">
              <Label>Hombres</Label>
              <Input type="number" min="0" defaultValue="0" />
            </div>
            <div className="space-y-2">
              <Label>Mujeres</Label>
              <Input type="number" min="0" defaultValue="0" />
            </div>
            <div className="space-y-2">
              <Label>Otros</Label>
              <Input type="number" min="0" defaultValue="0" />
            </div>
          </div>
          
          <div className="space-y-2">
            <Label>Población con Enfoque Diferencial (Total estimado)</Label>
            <div className="grid grid-cols-2 gap-4 p-4 rounded-xl border border-[var(--border)] bg-[var(--surface-1)]">
              <div className="space-y-2">
                <Label className="text-xs text-[var(--text-secondary)]">Víctimas (Ley 1448)</Label>
                <Input type="number" min="0" defaultValue="0" />
              </div>
              <div className="space-y-2">
                <Label className="text-xs text-[var(--text-secondary)]">Discapacidad (Ley 1618)</Label>
                <Input type="number" min="0" defaultValue="0" />
              </div>
            </div>
          </div>
        </section>
      </div>
    </PanelShell>
  );
}
