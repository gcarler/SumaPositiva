import type { Meta, StoryObj } from "@storybook/nextjs-vite";
import { expect, userEvent, waitFor, within } from "storybook/test";
import { QueryProvider } from "@/app/_composition/query-provider";
import Home from "@/app/page";
import { PanelHost } from "@/app/_components/panel-host";
import { Toaster } from "@/shared/ui/sonner";
import { useNavigationStore } from "@/core/navigation/navigation-store";
import { usePanelStore } from "@/core/panels/panel-store";
import { usePoliticasStore } from "@/features/politicas/state/politicas-store";
import { useMesasStore } from "@/features/mesas/state/mesas-store";
import { useSesionStore } from "@/features/sesion/state/session-store";
import { POLITICAS_MOCK } from "@/features/politicas/data/politicas.mock";
import { MESAS_MOCK } from "@/features/mesas/data/mesas.mock";

const meta = {
  title: "Plataforma/Pantallas",
  parameters: {
    layout: "fullscreen",
    polis: { screen: true },
    docs: {
      story: { inline: false },
      description: {
        component:
          "Pantallas reales de POLIS con datos de demostración aislados. Comparten componentes, tokens y comportamiento con la aplicación; no requieren API.",
      },
    },
  },
  beforeEach: () => {
    const fetchOriginal = window.fetch;
    // Aislar las pantallas de demostración: las consultas leen el store de la historia.
    window.fetch = async (entrada, opciones) => {
      const ruta = new URL(typeof entrada === "string" ? entrada : entrada instanceof Request ? entrada.url : entrada.href,
        window.location.origin).pathname;
      if (ruta.startsWith("/api/v1/")) {
        const mesaId = /^\/api\/v1\/mesas\/([^/]+)$/.exec(ruta)?.[1];
        if (ruta === "/api/v1/mesas") return Response.json(useMesasStore.getState().mesas);
        if (mesaId) {
          const mesa = useMesasStore.getState().mesas.find((m) => m.id === mesaId);
          return mesa ? Response.json(mesa) : Response.json({detail: "Mesa no encontrada"}, {status: 404});
        }
        return Response.json({detail: "Ruta sin datos en esta historia"}, {status: 404});
      }
      return fetchOriginal(entrada, opciones);
    };
    usePanelStore.getState().closeAll();
    useNavigationStore.setState({ vista: "inicio" });
    usePoliticasStore.setState({
      politicas: structuredClone(POLITICAS_MOCK),
      busqueda: "",
      sectorFiltro: "todos",
      estadoFiltro: "todos",
    });
    useMesasStore.setState({ mesas: structuredClone(MESAS_MOCK) });
    useSesionStore.setState({ sesion: null });
    return () => {
      window.fetch = fetchOriginal;
      usePanelStore.getState().closeAll();
      useSesionStore.setState({ sesion: null });
    };
  },
  render: () => (
    <QueryProvider>
      <Home />
      <PanelHost />
      <Toaster />
    </QueryProvider>
  ),
} satisfies Meta;
export default meta;
type Story = StoryObj<typeof meta>;
export const Inicio: Story = {};
export const InicioOscuro: Story = { globals: { theme: "dark" } };
export const Explorar: Story = {
  beforeEach: () => {
    useNavigationStore.setState({ vista: "explorar" });
  },
};
export const Mesas: Story = {
  beforeEach: () => {
    useNavigationStore.setState({ vista: "mesas" });
  },
};
export const SinResultados: Story = {
  beforeEach: () => {
    useNavigationStore.setState({ vista: "explorar" });
    usePoliticasStore.setState({ busqueda: "Una búsqueda sin coincidencias" });
  },
};
export const Politica: Story = {
  beforeEach: () => {
    usePanelStore.getState().openPanel("politica", { politicaId: "pol-001" });
  },
};
export const Fase: Story = {
  beforeEach: () => {
    usePanelStore
      .getState()
      .openPanel("fase", { politicaId: "pol-001", faseId: "fase-001-1" });
  },
};
export const Linea: Story = {
  beforeEach: () => {
    usePanelStore
      .getState()
      .openPanel("linea", {
        politicaId: "pol-001",
        faseId: "fase-001-1",
        lineaId: "lin-001-1-1",
      });
  },
};
export const NuevoAporte: Story = {
  beforeEach: () => {
    usePanelStore
      .getState()
      .openPanel("aporte", {
        politicaId: "pol-001",
        faseId: "fase-001-1",
        lineaId: "lin-001-1-1",
      });
  },
};
export const Participar: Story = {
  beforeEach: () => {
    usePanelStore.getState().openPanel("sesion", {});
  },
};
export const Mesa: Story = {
  beforeEach: () => {
    useNavigationStore.setState({ vista: "mesas" });
    usePanelStore.getState().openPanel("mesa", { mesaId: "mesa-001" });
  },
};
export const CrearMesa: Story = {
  beforeEach: () => {
    useNavigationStore.setState({ vista: "mesas" });
    usePanelStore.getState().openPanel("mesa-editor", {});
  },
};
export const Papelografo: Story = {
  beforeEach: () => {
    useNavigationStore.setState({ vista: "mesas" });
    usePanelStore
      .getState()
      .openPanel("papelografo", {
        mesaId: "mesa-001",
        submesaId: "sm-001-1",
        arbol: "problemas",
      });
  },
};
export const NavegacionConTeclado: Story = {
  play: async ({ canvasElement }) => {
    const canvas = within(canvasElement);
    const trigger = canvas.getByRole("button", {
      name: /Abrir panel de sesión/i,
    });
    await userEvent.click(trigger);
    const dialog = await canvas.findByRole("dialog");
    await expect(dialog).toHaveFocus();
    await expect(
      canvasElement.querySelector("#polis-application"),
    ).toHaveAttribute("inert");
    await userEvent.keyboard("{Escape}");
    await expect(trigger).toHaveFocus();
  },
};

export const CrearMesaCompleta: Story = {
  ...CrearMesa,
  play: async ({ canvasElement }) => {
    const canvas = within(canvasElement);
    const panel = within(await canvas.findByRole("dialog"));
    await userEvent.type(
      panel.getByLabelText(/Nombre de la mesa/),
      "Mesa de convivencia barrial",
    );
    await userEvent.type(
      panel.getByLabelText(/Entidad que convoca/),
      "Secretaría de Participación",
    );
    await userEvent.type(panel.getByLabelText(/Fecha/), "2026-10-15");
    const attendees = panel.getByLabelText(/Total de asistentes/);
    await userEvent.clear(attendees);
    await userEvent.type(attendees, "24");
    await userEvent.type(panel.getByLabelText(/Lugar/), "Casa de la cultura");
    await userEvent.type(
      panel.getByLabelText(/Funcionario facilitador/),
      "Ana Torres",
    );
    const submit = panel.getByRole("button", { name: "Crear mesa" });
    await waitFor(() => expect(submit).toBeEnabled());
    await userEvent.click(submit);
    await waitFor(() =>
      expect(
        useMesasStore
          .getState()
          .mesas.some((mesa) => mesa.nombre === "Mesa de convivencia barrial"),
      ).toBe(true),
    );
    await expect(
      await canvas.findByRole("dialog", {
        name: "Mesa de convivencia barrial",
      }),
    ).toBeVisible();
  },
};
