import type { Metadata, Viewport } from "next";
import { MotionConfig } from "framer-motion";
import { ThemeProvider } from "next-themes";
import { Toaster } from "@/shared/ui/sonner";
import "./globals.css";
import { PanelHost } from "@/app/_components/panel-host";
import { SesionSync } from "@/app/_composition/sesion-sync";
import { QueryProvider } from "@/app/_composition/query-provider";

export const metadata: Metadata = {
  title: "POLIS — Participación Ciudadana en Políticas Públicas",
  description:
    "Explora las políticas públicas en curso, entra fase por fase y línea estratégica por línea estratégica, y deja tus propuestas, anotaciones y preguntas donde se toman las decisiones.",
  keywords: [
    "participación ciudadana",
    "políticas públicas",
    "presupuesto participativo",
    "consulta pública",
    "deliberación",
  ],
};

export const viewport: Viewport = {
  themeColor: [
    { media: "(prefers-color-scheme: light)", color: "#fafaf9" },
    { media: "(prefers-color-scheme: dark)", color: "#0d0d10" },
  ],
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="es" suppressHydrationWarning>
      <body
        className="antialiased bg-background text-foreground font-sans"
      >
        <QueryProvider>
          <SesionSync />
          <ThemeProvider
            attribute="class"
            defaultTheme="system"
            enableSystem
            disableTransitionOnChange
          >
            <MotionConfig reducedMotion="user">
            {children}

            {/* Zero-Modals: host global de paneles apilados */}
            <PanelHost />

            {/* Notificaciones */}
            <Toaster />
            </MotionConfig>
          </ThemeProvider>
        </QueryProvider>
      </body>
    </html>
  );
}
