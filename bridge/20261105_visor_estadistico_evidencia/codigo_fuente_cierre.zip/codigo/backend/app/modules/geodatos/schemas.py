import uuid
from datetime import datetime
from decimal import Decimal
from typing import Any

from pydantic import BaseModel, ConfigDict, Field, model_validator


class TerritorioBase(BaseModel):
    codigo: str = Field(..., max_length=50, description="Código único del territorio")
    nombre: str = Field(..., max_length=200, description="Nombre oficial del territorio")
    tipo_territorio: str = Field(
        ...,
        max_length=50,
        description=("Nivel: distrito, localidad, unidad_actuacion_comunera, barrio, corregimiento o zona_insular"),
    )
    territorio_padre_id: uuid.UUID | None = Field(default=None, description="UUID del territorio padre")
    poblacion_estimada: int | None = Field(default=None, description="Población estimada")
    estrato_predominante: int | None = Field(default=None, description="Estrato socioeconómico predominante")
    es_zona_etnica: bool = Field(
        default=False,
        description="Indica si es comunidad negra/afrodescendiente o resguardo indígena",
    )
    nombre_consejo_comunitario: str | None = Field(
        default=None, max_length=250, description="Nombre del Consejo Comunitario de la zona"
    )
    metadatos: dict[str, Any] = Field(default_factory=dict, description="Metadatos adicionales")


class TerritorioCreate(TerritorioBase):
    """Esquema para creación de territorio."""

    pass


class TerritorioRead(TerritorioBase):
    """Esquema de lectura para territorio con coordenadas de centroide."""

    id: uuid.UUID
    coordenadas_centroide: tuple[float, float] | None = Field(
        default=None, description="Coordenadas geográficas [longitud, latitud] EPSG:4326"
    )
    creado_en: datetime
    actualizado_en: datetime

    model_config = ConfigDict(from_attributes=True)


class IndicadorTerritorioBase(BaseModel):
    """Esquema base para indicador estadístico territorial."""

    territorio_id: uuid.UUID = Field(..., description="UUID del territorio asociado")
    dimension_id: uuid.UUID | None = Field(default=None, description="UUID de la dimensión de seguridad humana")
    codigo_indicador: str = Field(..., max_length=100, description="Código único del indicador")
    nombre_indicador: str = Field(..., max_length=250, description="Nombre del indicador")
    valor: Decimal = Field(..., description="Valor cuantitativo del indicador")
    unidad_medida: str = Field(..., max_length=50, description="Unidad de medida")
    nivel_riesgo: str = Field(
        default="medio",
        max_length=30,
        description="Nivel de riesgo: bajo, medio, alto o critico",
    )
    anio_corte: int = Field(default=2026, description="Año de corte del indicador")
    fuente_datos: str = Field(..., max_length=200, description="Fuente oficial de los datos")
    metadatos: dict[str, Any] = Field(default_factory=dict, description="Metadatos en JSONB")


class IndicadorTerritorioCreate(IndicadorTerritorioBase):
    """Esquema de creación para indicador territorial."""

    pass


class IndicadorTerritorioRead(IndicadorTerritorioBase):
    """Esquema de lectura para indicador territorial."""

    id: uuid.UUID
    creado_en: datetime
    actualizado_en: datetime

    model_config = ConfigDict(from_attributes=True)


class IndicadorTerritorioDetalladoRead(IndicadorTerritorioRead):
    """Esquema de lectura para indicador territorial con detalles del territorio y dimensión."""

    codigo_territorio: str | None = Field(default=None, description="Código único del territorio (ej. DISTRITO-CTG)")
    nombre_territorio: str | None = Field(default=None, description="Nombre oficial del territorio")
    codigo_dimension: str | None = Field(default=None, description="Código de la dimensión de seguridad humana")
    nombre_dimension: str | None = Field(default=None, description="Nombre oficial de la dimensión")


class IndicadoresTerritorioResponse(BaseModel):
    """Respuesta paginada y filtrada para consulta de indicadores territoriales."""

    total: int = Field(..., ge=0, description="Total de registros que coinciden con los filtros")
    limit: int = Field(..., ge=1, description="Límite de registros por página")
    offset: int = Field(..., ge=0, description="Desplazamiento aplicado")
    indicadores: list[IndicadorTerritorioDetalladoRead] = Field(
        default_factory=list, description="Lista de indicadores territoriales"
    )


class FiltrosMultifuente(BaseModel):
    codigo_territorio: str | None = Field(default=None, max_length=80)
    fuente_datos: str | None = Field(default=None, max_length=200)
    dimension: str | None = Field(default=None, max_length=40)
    anio_desde: int | None = Field(default=None, ge=1900, le=2200)
    anio_hasta: int | None = Field(default=None, ge=1900, le=2200)
    busqueda: str | None = Field(default=None, max_length=200)
    incluir_ediciones_previas: bool = False


class OpcionMultifuente(BaseModel):
    id: str
    nombre: str
    total: int = Field(ge=0)


class SerieMultifuenteResumen(BaseModel):
    id: str
    codigo_indicador: str
    nombre: str
    fuente: str
    unidad: str
    territorio_id: str
    codigo_territorio: str
    territorio: str
    escala: str
    dimension: str | None
    subtipo: str
    total: int
    anios: list[int]
    advertencias: list[str]


class PuntoMultifuente(BaseModel):
    observacion_id: str
    anio: int
    valor: float | None
    valor_original: str
    periodo_desde: str | None
    periodo_hasta: str | None
    tipo_periodo: str
    completo: bool | None
    provisional: bool
    url_fuente: str | None
    sha256: str | None
    fecha_extraccion: str | None
    referencia: str | None
    nota: str | None
    estado_validacion: str | None
    estado_publicacion: str | None
    universo: str | None
    metodo: str | None
    advertencias: list[str]


class SerieMultifuenteDetalle(BaseModel):
    resumen: SerieMultifuenteResumen
    puntos: list[PuntoMultifuente]
    minimo: float | None
    maximo: float | None
    mediana: float | None
    variacion_interanual_pct: float | None
    motivo_variacion: str


class ParMultifuente(BaseModel):
    anio: int
    x: float
    y: float
    observacion_x: str
    observacion_y: str
    elegible: bool
    motivos: list[str]


class ComparacionMultifuente(BaseModel):
    serie_x: str
    serie_y: str
    pares: list[ParMultifuente]
    anios_sin_pareja: list[int]
    muestra_total: int
    muestra_elegible: int
    pearson: float | None = None
    spearman: float | None = None
    estado: str
    motivos: list[str]
    interpretacion: str


class AnaliticaMultifuenteResponse(BaseModel):
    version_metodo: str
    consulta_sha256: str
    total_observaciones: int
    observaciones_excluidas: int
    fuentes: list[OpcionMultifuente]
    territorios: list[OpcionMultifuente]
    dimensiones: list[OpcionMultifuente]
    anios: list[int]
    cobertura_fuentes: list[OpcionMultifuente]
    series: list[SerieMultifuenteResumen]
    serie: SerieMultifuenteDetalle | None
    serie_comparada: SerieMultifuenteDetalle | None
    comparacion: ComparacionMultifuente | None
    advertencias: list[str]


class CapaGeovisorBase(BaseModel):
    """Esquema base para capa espacial del Geovisor."""

    codigo: str = Field(..., max_length=50, description="Código único de la capa")
    nombre: str = Field(..., max_length=200, description="Nombre visible de la capa")
    categoria: str = Field(..., max_length=100, description="Categoría temática")
    descripcion: str | None = Field(default=None, description="Descripción funcional de la capa")
    tipo_geometria: str = Field(default="Poligonos", max_length=50, description="Tipo: Puntos, Poligonos, MapaCalor")
    color_estilo: str = Field(default="#ef4444", max_length=7, description="Código de color hexadecimal")
    activa: bool = Field(default=True, description="Estado de visibilidad")
    metadatos: dict[str, Any] = Field(default_factory=dict, description="Metadatos de la capa")


class CapaGeovisorCreate(CapaGeovisorBase):
    """Esquema de creación para capa del geovisor."""

    pass


class CapaGeovisorRead(CapaGeovisorBase):
    """Esquema de lectura para capa del geovisor."""

    id: uuid.UUID
    creado_en: datetime
    actualizado_en: datetime

    model_config = ConfigDict(from_attributes=True)


class CoordenadasAproximadas(BaseModel):
    """Coordenadas geográficas WGS84 EPSG:4326 del territorio o punto normalizado."""

    latitud: float = Field(..., description="Latitud en grados decimales (-90 a 90)")
    longitud: float = Field(..., description="Longitud en grados decimales (-180 a 180)")


class EstandarizarDireccionRequest(BaseModel):
    """Solicitud de estandarización léxica y territorial de dirección."""

    direccion_raw: str = Field(
        ...,
        min_length=2,
        max_length=300,
        description="Dirección o referencia territorial en texto libre",
    )


class DireccionEstandarizadaResponse(BaseModel):
    """Respuesta con dirección normalizada, desglose de vía/sector y georreferenciación distrital."""

    direccion_original: str = Field(..., description="Texto original proporcionado")
    direccion_normalizada: str = Field(..., description="Dirección normalizada según nomenclatura distrital oficial")
    tipo_via: str | None = Field(
        default=None,
        description="Tipo de vía: Calle, Carrera, Diagonal, Transversal, Avenida, Sector, etc.",
    )
    numero_principal: str | None = Field(
        default=None,
        description="Número de vía principal o identificador de manzana/sector",
    )
    numero_secundario: str | None = Field(
        default=None,
        description="Número de cruce/placa o identificador de lote",
    )
    sector_o_barrio: str | None = Field(
        default=None,
        description="Sector, barrio o territorio identificado en Cartagena",
    )
    territorio_id: uuid.UUID | None = Field(
        default=None,
        description="UUID del territorio en geodatos.territorios si existe correspondencia",
    )
    coordenadas_aproximadas: CoordenadasAproximadas | None = Field(
        default=None,
        description="Coordenadas geográficas aproximadas [latitud, longitud]",
    )
    confianza: float = Field(
        ...,
        ge=0.0,
        le=1.0,
        description="Nivel de confianza de la estandarización (0.0 a 1.0)",
    )


class NodoCercanoRead(BaseModel):
    """Información del nodo de seguridad o salud más cercano."""

    nombre: str = Field(..., description="Nombre del nodo de seguridad humana")
    tipo: str = Field(..., description="Tipo de nodo: seguridad, salud, justicia")
    distancia_metros: float = Field(..., description="Distancia geodésica en metros desde el origen")


class IsocronaProperties(BaseModel):
    """Propiedades temáticas y temporales del polígono de isócrona."""

    minutos: int = Field(..., description="Intervalo temporal en minutos (5, 10, 15)")
    modo: str = Field(..., description="Modo de desplazamiento: 'pie' o 'vehiculo'")
    radio_metros: float = Field(..., description="Radio de cobertura estimado en metros")
    metodo_calculo: str = Field(
        default="buffer_euclidiano_geodesico",
        description="Metodología de cálculo: buffer euclidiano/geodésico o ruteo en red vial",
    )
    nodo_cercano: NodoCercanoRead | None = Field(
        default=None, description="Nodo de seguridad humana más cercano alcanzable"
    )


class IsocronaFeature(BaseModel):
    """Feature GeoJSON de isócrona poligonal."""

    type: str = Field(default="Feature", description="Tipo GeoJSON Feature")
    geometry: dict[str, Any] = Field(..., description="Geometría Polygon o MultiPolygon GeoJSON")
    properties: IsocronaProperties = Field(..., description="Propiedades de la isócrona")


class IsocronasFeatureCollection(BaseModel):
    """Colección GeoJSON de polígonos de isócronas para el Geovisor."""

    type: str = Field(default="FeatureCollection", description="Tipo GeoJSON FeatureCollection")
    features: list[IsocronaFeature] = Field(
        default_factory=list, description="Lista de polígonos de cobertura temporal"
    )


class SerieTemporalItem(BaseModel):
    """Elemento de serie temporal anual o mensual."""

    periodo: str = Field(..., description="Año o mes analizado")
    cantidad: int = Field(..., description="Cantidad total de incidentes")
    etiqueta: str = Field(default="", description="Etiqueta para visualización frontend")
    porcentaje: float = Field(default=0.0, description="Porcentaje de participación")

    @model_validator(mode="before")
    @classmethod
    def asegurar_etiqueta_y_porcentaje(cls, data: Any) -> Any:
        if isinstance(data, dict):
            data = dict(data)
            if not data.get("etiqueta") and data.get("periodo"):
                data["etiqueta"] = str(data["periodo"])
            if not data.get("periodo") and data.get("etiqueta"):
                data["periodo"] = str(data["etiqueta"])
            if "porcentaje" not in data:
                data["porcentaje"] = 0.0
        return data


class CategoriaConteo(BaseModel):
    """Categoría con su frecuencia y participación porcentual."""

    categoria: str = Field(..., description="Nombre de la categoría")
    cantidad: int = Field(..., description="Número de incidentes")
    porcentaje: float = Field(..., description="Porcentaje sobre el total analizado")
    arma: str | None = Field(default=None, description="Sinónimo para arma/medio")
    sitio: str | None = Field(default=None, description="Sinónimo para clase de sitio")

    @model_validator(mode="before")
    @classmethod
    def asegurar_sinonimos(cls, data: Any) -> Any:
        if isinstance(data, dict):
            data = dict(data)
            cat = str(data.get("categoria") or data.get("arma") or data.get("sitio") or "")
            data["categoria"] = cat
            if "arma" not in data or data["arma"] is None:
                data["arma"] = cat
            if "sitio" not in data or data["sitio"] is None:
                data["sitio"] = cat
        return data


class DistribucionZonaItem(BaseModel):
    """Desglose por zona geográfica urbana vs rural."""

    zona: str = Field(..., description="URBANA o RURAL")
    cantidad: int = Field(..., description="Número de incidentes")
    porcentaje: float = Field(..., description="Porcentaje sobre el total analizado")


class ResumenHurtosResponse(BaseModel):
    """Resumen estadístico y analítico de hurtos para el Geovisor."""

    total_casos: int = Field(..., description="Total de casos registrados según filtros")
    delito: str | None = Field(default=None, description="Filtro de delito aplicado")
    anio: int | None = Field(default=None, description="Filtro de año aplicado")
    zona: str | None = Field(default=None, description="Filtro de zona aplicado")
    serie_anual: list[SerieTemporalItem] = Field(default_factory=list, description="Serie temporal anual 2018-2026")
    serie_mensual: list[SerieTemporalItem] = Field(default_factory=list, description="Distribución mensual")
    top_armas: list[CategoriaConteo] = Field(default_factory=list, description="Top 5 armas o medios empleados")
    top_sitios: list[CategoriaConteo] = Field(default_factory=list, description="Top 5 clases de sitio")
    distribucion_zona: list[DistribucionZonaItem] = Field(
        default_factory=list, description="Distribución por zona urbana vs rural"
    )


class HurtoPoligonoProperties(BaseModel):
    """Propiedades analíticas asociadas a cada polígono base."""

    poligono_id: int = Field(..., description="ID del polígono (1 Urbano, 2 Rural)")
    codigo: str = Field(..., description="Código oficial del polígono")
    nombre: str = Field(..., description="Nombre descriptivo del polígono")
    zona: str = Field(..., description="URBANA o RURAL")
    area_km2: float | None = Field(default=None, description="Área superficial en km2")
    delito: str | None = Field(default=None, description="Delito analizado")
    anio: int | None = Field(default=None, description="Año analizado o null para consolidado")
    total_casos: int = Field(..., description="Total de casos en este polígono")
    densidad_casos_km2: float = Field(..., description="Casos por kilómetro cuadrado")
    porcentaje_total: float = Field(..., description="Participación porcentual sobre el distrito")
    top_armas: list[CategoriaConteo] = Field(default_factory=list)
    top_sitios: list[CategoriaConteo] = Field(default_factory=list)


class HurtoFeature(BaseModel):
    """Feature GeoJSON de polígono analítico de hurtos."""

    type: str = Field(default="Feature", description="Tipo GeoJSON Feature")
    id: int = Field(..., description="ID numérico del polígono")
    geometry: dict[str, Any] = Field(..., description="Geometría MultiPolygon EPSG:4326")
    properties: HurtoPoligonoProperties = Field(..., description="Propiedades analíticas")


class HurtosFeatureCollection(BaseModel):
    """Colección GeoJSON con los polígonos urbano y rural y sus estadísticas asociadas."""

    type: str = Field(default="FeatureCollection", description="Tipo GeoJSON FeatureCollection")
    features: list[HurtoFeature] = Field(default_factory=list, description="Polígonos temáticos analíticos")


class RegistroHurtoItem(BaseModel):
    """Registro individual estructurado del dataset GeoJSON de hurtos."""

    id: uuid.UUID
    delito: str
    anio: int
    mes: str
    dia_semana: str
    zona: str
    poligono_id: int
    armas_medios: str
    clase_sitio: str
    cantidad: int

    model_config = ConfigDict(from_attributes=True)


class AgrupacionHurtoItem(BaseModel):
    """Fila agregada del procesamiento analítico / pivot dinámico."""

    categoria: str
    registros: int
    incidentes: int
    porcentaje: float


class CatalogosHurtos(BaseModel):
    """Catálogos de valores únicos para selectores y filtros del frontend."""

    meses: list[str] = Field(default_factory=list)
    dias_semana: list[str] = Field(default_factory=list)
    top_armas_medios: list[str] = Field(default_factory=list)
    top_clases_sitio: list[str] = Field(default_factory=list)


class ExploradorHurtosResponse(BaseModel):
    """Respuesta estructurada para exploración tabular, filtrado multicriterio y pivot dinámico."""

    total_registros: int
    total_incidentes: int
    limit: int
    offset: int
    registros: list[RegistroHurtoItem] = Field(default_factory=list)
    agrupacion: list[AgrupacionHurtoItem] = Field(default_factory=list)
    catalogos: CatalogosHurtos
